import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

const Index = () => {
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Commande envoyée ! Nous vous contacterons bientôt.");
    setFormData({ nom: '', email: '', message: '' });
  };

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen">
      {/* Header with Chocolate Drip Animation */}
      <header className="text-center relative pb-4">
        <div className="drip-animation animate-drip"></div>
        
        <h1 className="site-title inline-block bg-white/75 rounded-3xl px-7 py-3 -mt-6 shadow-lg animate-bounce-in">
          <span className="text-2xl mr-2">🍪</span>
          Shan's Cookies Delices
        </h1>
        
        <div className="subtitle-text mt-2 mb-4 animate-fade-in opacity-0" style={{animationDelay: '1.2s', animationFillMode: 'forwards'}}>
          Pour les becs sucrés
        </div>

        <nav className="mt-4 sticky top-0 z-50 bg-white/85 backdrop-blur-sm p-2 rounded-2xl inline-block shadow-lg">
          <button onClick={() => scrollToSection('accueil')} className="btn-nav">Accueil</button>
          <button onClick={() => scrollToSection('apropos')} className="btn-nav">À propos</button>
          <button onClick={() => scrollToSection('menu')} className="btn-nav">Menu</button>
          <button onClick={() => scrollToSection('produits')} className="btn-nav">Produits</button>
          <button onClick={() => scrollToSection('contact')} className="btn-nav">Contact</button>
        </nav>
      </header>

      {/* Hero Section */}
      <section 
        id="accueil" 
        className="mx-auto max-w-4xl my-8 p-12 rounded-3xl text-center shadow-lg animate-fade-in opacity-0"
        style={{
          backgroundImage: "url('https://littlespoonfarm.com/wp-content/uploads/2021/10/Chewy-chocolate-chip-cookies-on-a-plate-_.jpg')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          animationDelay: '1.6s',
          animationFillMode: 'forwards'
        }}
      >
        <h1 className="hero-text bg-white/80 inline-block px-6 py-3 rounded-2xl animate-bounce-in" style={{animationDelay: '1.7s'}}>
          Des cookies faits avec amour ❤️
        </h1>
        <div className="subtitle-text bg-white/80 inline-block mt-4 px-4 py-2 rounded-xl animate-fade-in opacity-0" style={{animationDelay: '2s', animationFillMode: 'forwards'}}>
          Pour les becs sucrés !
        </div>
      </section>

      {/* About Section */}
      <section id="apropos" className="text-center py-12 px-5 animate-fade-in opacity-0" style={{animationDelay: '2.2s', animationFillMode: 'forwards'}}>
        <h2 className="section-title animate-bounce-in" style={{animationDelay: '2.3s'}}>À propos</h2>
        <div className="max-w-3xl mx-auto">
          <p className="text-lg leading-relaxed">
            Bienvenue chez <strong>Shan's Cookies Delices</strong> !<br/>
            Nous réalisons des cookies artisanaux, gourmands et moelleux, pour toutes les envies sucrées.<br/>
            À partager ou à garder pour soi, ils sont parfaits pour toutes les occasions.
          </p>
        </div>
      </section>

      {/* Menu Section */}
      <section 
        id="menu" 
        className="max-w-4xl mx-auto my-10 p-10 bg-cream/90 backdrop-blur-sm rounded-3xl shadow-lg animate-fade-in opacity-0"
        style={{animationDelay: '2.8s', animationFillMode: 'forwards'}}
      >
        <h2 className="section-title text-center">Menu des Saveurs</h2>

        <div className="grid md:grid-cols-3 gap-8 mt-8">
          <div>
            <h3 className="text-xl font-bold text-gold mb-4 font-fredoka">🍪 Saveurs uniques</h3>
            <ul className="space-y-2 text-choco">
              <li>• Vanille</li>
              <li>• Noisettes grillées</li>
              <li>• Miel doré</li>
              <li>• Muscade</li>
              <li>• Chocolat noir</li>
              <li>• Chocolat blanc</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold text-gold mb-4 font-fredoka">🥠 Duos (2 saveurs)</h3>
            <ul className="space-y-1 text-sm text-choco">
              <li>• Vanille & Noisettes</li>
              <li>• Vanille & Miel</li>
              <li>• Vanille & Muscade</li>
              <li>• Vanille & Chocolat Noir</li>
              <li>• Vanille & Chocolat Blanc</li>
              <li>• Miel & Noisettes</li>
              <li>• Miel & Muscade</li>
              <li>• Miel & Chocolat Noir</li>
              <li>• Miel & Chocolat Blanc</li>
              <li>• Muscade & Noisettes</li>
              <li>• Muscade & Chocolat Noir</li>
              <li>• Muscade & Chocolat Blanc</li>
              <li>• Chocolat Noir & Noisettes</li>
              <li>• Chocolat Noir & Chocolat Blanc</li>
              <li>• Chocolat Blanc & Noisettes</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold text-gold mb-4 font-fredoka">🍩 Trios (3 saveurs)</h3>
            <ul className="space-y-1 text-sm text-choco">
              <li>• Vanille, Noisettes & Miel</li>
              <li>• Vanille, Miel & Muscade</li>
              <li>• Vanille, Chocolat Noir & Noisettes</li>
              <li>• Vanille, Chocolat Blanc & Noisettes</li>
              <li>• Vanille, Chocolat Noir & Miel</li>
              <li>• Vanille, Chocolat Blanc & Miel</li>
              <li>• Vanille, Muscade & Chocolat Noir</li>
              <li>• Vanille, Muscade & Noisettes</li>
              <li>• Vanille, Muscade & Miel</li>
              <li>• Miel, Noisettes & Chocolat Noir</li>
              <li>• Miel, Noisettes & Chocolat Blanc</li>
              <li>• Miel, Chocolat Noir & Muscade</li>
              <li>• Muscade, Chocolat Noir & Noisettes</li>
            </ul>
          </div>
        </div>

        <div className="text-center mt-8">
          <a 
            href="https://wa.me/22996600126?text=Bonjour%20Shan%27s%20Cookies%20Delices%2C%20je%20souhaite%20commander%20des%20cookies%20du%20menu"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Commander maintenant
          </a>
        </div>
      </section>

      {/* Products Section */}
      <section id="produits" className="py-12 px-5 animate-fade-in opacity-0" style={{animationDelay: '3.1s', animationFillMode: 'forwards'}}>
        <h2 className="section-title text-center">Nos Produits</h2>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Product 1 - Chocolate Cookie */}
          <Card className="product-card group">
            <CardContent className="p-6 text-center">
              <img 
                src="https://jamiegeller.com/.image/c_limit%2Ccs_srgb%2Cq_auto:good%2Cw_700/MTY1NTI0ODM1MDA3MDc5OTc0/chocolate-chocolate-cookies.webp"
                alt="Cookie chocolat double chocolat avec pépites"
                className="w-4/5 mx-auto rounded-xl border-2 border-rose mb-4 shadow-lg animate-float"
                loading="lazy"
              />
              <h3 className="text-xl font-bold text-gold mb-3 font-fredoka">Cookie Chocolat</h3>
              <p className="text-gold mb-4">Un classique moelleux avec des pépites de chocolat noir fondantes.</p>
              <a 
                href="https://wa.me/22996600126?text=Bonjour%20Shan%27s%20Cookies%20Delices%2C%20je%20souhaite%20commander%20%3A%20Cookie%20Chocolat%20(x%20quantite)"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Commander
              </a>
            </CardContent>
          </Card>

          {/* Product 2 - Caramel Cookie */}
          <Card className="product-card group">
            <CardContent className="p-6 text-center">
              <img 
                src="https://lesgourmandisesdekarelle.com/wp-content/uploads/2021/01/IMG-3283-1.jpg"
                alt="Cookie caramel beurre salé avec coulure de caramel"
                className="w-4/5 mx-auto rounded-xl border-2 border-rose mb-4 shadow-lg animate-float"
                loading="lazy"
                style={{animationDelay: '0.5s'}}
              />
              <h3 className="text-xl font-bold text-gold mb-3 font-fredoka">Cookie Caramel Beurre Salé</h3>
              <p className="text-gold mb-4">Un goût unique entre douceur et caractère, avec du caramel coulant.</p>
              <a 
                href="https://wa.me/22996600126?text=Bonjour%20Shan%27s%20Cookies%20Delices%2C%20je%20souhaite%20commander%20%3A%20Cookie%20Caramel%20Beurre%20Sale%20(x%20quantite)"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Commander
              </a>
            </CardContent>
          </Card>

          {/* Product 3 - Nuts & Honey Cookie */}
          <Card className="product-card group">
            <CardContent className="p-6 text-center">
              <img 
                src="https://elodiecharbonnier-dieteticienne.fr/wp-content/uploads/2020/11/E632702E-B711-4DFA-949F-7C1700EB3472_1_201_a.jpeg"
                alt="Cookie aux noix et miel doré"
                className="w-4/5 mx-auto rounded-xl border-2 border-rose mb-4 shadow-lg animate-float"
                loading="lazy"
                style={{animationDelay: '1s'}}
              />
              <h3 className="text-xl font-bold text-gold mb-3 font-fredoka">Cookie Noix & Miel</h3>
              <p className="text-gold mb-4">Pour les amateurs de saveurs naturelles et gourmandes.</p>
              <a 
                href="https://wa.me/22996600126?text=Bonjour%20Shan%27s%20Cookies%20Delices%2C%20je%20souhaite%20commander%20%3A%20Cookie%20Noix%20%26%20Miel%20(x%20quantite)"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Commander
              </a>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-12 px-5 text-center animate-fade-in opacity-0" style={{animationDelay: '3.3s', animationFillMode: 'forwards'}}>
        <h2 className="section-title">Contact</h2>
        
        <div className="max-w-md mx-auto bg-cream/75 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="text"
              placeholder="Votre nom"
              value={formData.nom}
              onChange={(e) => setFormData({...formData, nom: e.target.value})}
              className="form-input"
              required
            />
            <Input
              type="email"
              placeholder="Votre email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              className="form-input"
              required
            />
            <Textarea
              placeholder="Votre commande (type de cookies, quantité...)"
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
              className="form-input resize-none"
              rows={5}
              required
            />
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-gold to-honey hover:from-honey hover:to-gold text-white font-fredoka text-lg py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105"
            >
              Envoyer la commande
            </Button>
          </form>

          <p className="mt-6 text-choco">Ou commandez directement :</p>
          <a 
            href="https://wa.me/22996600126"
            target="_blank"
            rel="noopener noreferrer"
            className="whatsapp-btn mt-4 animate-fade-in opacity-0"
            style={{animationDelay: '3.37s', animationFillMode: 'forwards'}}
          >
            📱 Commander via WhatsApp
          </a>
          <div className="text-gold text-lg mt-3 font-semibold">
            Tel: +229 96 60 01 26
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center p-4 mt-8 bg-gradient-to-r from-rose to-honey text-gold font-bold text-lg rounded-t-2xl shadow-lg animate-fade-in opacity-0" style={{animationDelay: '3.6s', animationFillMode: 'forwards'}}>
        <p>&copy; 2025 Shan's Cookies Delices - Tous droits réservés</p>
      </footer>
    </div>
  );
};

export default Index;